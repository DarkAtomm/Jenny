package com.trolmastercard.sexmod;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;

public class d4 extends Entity {
    public d4(EntityType<? extends Entity> entityType, Level level) {
        super(entityType, level);
    }

    @Override
    public void tick() {
        super.tick();
        // Custom logic for entity
    }
}