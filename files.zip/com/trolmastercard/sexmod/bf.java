package com.trolmastercard.sexmod;

import net.minecraft.network.chat.Component;

public class bf {
    public static void sendChatMessage(String message) {
        System.out.println(Component.literal(message).getString());
    }
}