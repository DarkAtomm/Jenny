package com.trolmastercard.sexmod;

import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public class dw {
    @SubscribeEvent
    public void onRenderGameOverlay(RenderGameOverlayEvent event) {
        // Custom rendering logic for overlay
    }
}