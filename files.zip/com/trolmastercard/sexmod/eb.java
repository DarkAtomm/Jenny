package com.trolmastercard.sexmod;

import software.bernie.geckolib.core.IAnimatable;
import software.bernie.geckolib.core.IAnimatableModel;
import software.bernie.geckolib.core.processor.AnimationProcessor;
import software.bernie.geckolib.core.processor.IBone;

import java.util.HashMap;

public class eb<T extends IAnimatable> extends AnimationProcessor<T> {
    private final HashMap<String, IBone> bones = new HashMap<>();

    public eb(IAnimatableModel<T> model) {
        super(model);
    }

    @Override
    public IBone getBone(String name) {
        return this.bones.get(name);
    }

    @Override
    public void registerModelRenderer(IBone bone) {
        super.registerModelRenderer(bone);
        this.bones.put(bone.getName(), bone);
    }

    @Override
    public void clearModelRendererList() {
        super.clearModelRendererList();
        this.bones.clear();
    }
}