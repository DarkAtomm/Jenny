package com.trolmastercard.sexmod;

import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class bj extends Screen {
    protected bj(Component title) {
        super(title);
    }

    @Override
    protected void init() {
        super.init();
        // Add GUI elements here
    }

    @Override
    public void render(PoseStack poseStack, int mouseX, int mouseY, float partialTicks) {
        super.render(poseStack, mouseX, mouseY, partialTicks);
        // Custom rendering logic
    }
}