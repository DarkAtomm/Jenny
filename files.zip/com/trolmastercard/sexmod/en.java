package com.trolmastercard.sexmod;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;

public class en extends LivingEntity {
    protected en(EntityType<? extends LivingEntity> entityType, Level level) {
        super(entityType, level);
    }

    @Override
    public void tick() {
        super.tick();
        if (this.isAlive() && this.level.isClientSide) {
            // Custom logic for entity behavior
        }
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (source.isExplosion()) {
            this.remove(RemovalReason.KILLED);
            return true;
        }
        return super.hurt(source, amount);
    }
}