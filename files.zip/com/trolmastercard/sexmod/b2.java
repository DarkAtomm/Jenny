package com.trolmastercard.sexmod;

import net.minecraft.resources.ResourceLocation;

public class b2 {
    private static final ResourceLocation[] TEXTURES = {
        new ResourceLocation("sexmod", "textures/entity/allie/allie.geo.json"),
        new ResourceLocation("sexmod", "textures/entity/allie/armored.geo.json"),
        new ResourceLocation("sexmod", "textures/entity/allie/allie.geo.json")
    };

    public ResourceLocation getTexture(int index) {
        if (index < 0 || index >= TEXTURES.length) {
            return TEXTURES[0]; // Default texture
        }
        return TEXTURES[index];
    }
}