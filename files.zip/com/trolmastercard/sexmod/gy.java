package com.trolmastercard.sexmod;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class gy<K, V> {
    private final HashMap<K, V> forwardMap = new HashMap<>();
    private final HashMap<V, K> backwardMap = new HashMap<>();

    public void put(K key, V value) {
        V oldValue = this.forwardMap.put(key, value);
        this.backwardMap.remove(oldValue);
        this.backwardMap.put(value, key);
    }

    public V get(K key) {
        return this.forwardMap.get(key);
    }

    public K reverseGet(V value) {
        return this.backwardMap.get(value);
    }

    public int size() {
        return this.forwardMap.size();
    }

    public void remove(K key) {
        V value = this.forwardMap.remove(key);
        if (value != null) {
            this.backwardMap.remove(value);
        }
    }

    public Set<Map.Entry<K, V>> entrySet() {
        return this.forwardMap.entrySet();
    }

    public Set<K> keySet() {
        return this.forwardMap.keySet();
    }

    public Set<V> valueSet() {
        return this.backwardMap.keySet();
    }
}