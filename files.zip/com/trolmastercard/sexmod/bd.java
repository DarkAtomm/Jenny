package com.trolmastercard.sexmod;

import net.minecraftforge.network.PacketDistributor;

public class bd {
    public static void sendData(UUID targetUUID, PacketDistributor.PacketTarget target) {
        // Example logic to handle packet sending
        System.out.println("Sending data to: " + targetUUID);
    }
}